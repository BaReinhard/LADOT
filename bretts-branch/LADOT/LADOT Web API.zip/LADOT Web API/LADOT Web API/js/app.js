var app = angular.module('CarReservationApp', ['ngRoute', 'ngAnimate']); 

